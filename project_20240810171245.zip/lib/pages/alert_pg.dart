import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class AlertPg extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFFFFFFF),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(0, 17, 0, 0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(22, 0, 22, 35),
              child: Align(
                alignment: Alignment.topLeft,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 8, 3),
                      child: SizedBox(
                        width: 30,
                        height: 30,
                        child: SvgPicture.asset(
                          'assets/vectors/alert_triangle_5_x2.svg',
                        ),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 3, 0, 0),
                      child: Text(
                        'Alert',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w500,
                          fontSize: 25,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(15, 0, 20.7, 5),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 9, 0),
                    child: SizedBox(
                      width: 98,
                      child: Text(
                        'Your Location',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 15,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ),
                  Text(
                    'All India',
                    style: GoogleFonts.getFont(
                      'Inter',
                      fontWeight: FontWeight.w400,
                      fontSize: 15,
                      color: Color(0xFF000000),
                    ),
                  ),
                  Text(
                    'Weathers',
                    style: GoogleFonts.getFont(
                      'Inter',
                      fontWeight: FontWeight.w400,
                      fontSize: 15,
                      color: Color(0xFF000000),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 21),
              child: Container(
                decoration: BoxDecoration(
                  color: Color(0xFFB3B3B3),
                ),
                child: Container(
                  width: 360,
                  height: 0,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 0, 25, 5),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFF2F2F2),
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(4, 9, 4.8, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage(
                                    'assets/images/warm_weather.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 40,
                                height: 40,
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 2, 0, 2),
                            child: RichText(
                              text: TextSpan(
                                text: 'Saturday 11 August
                          ',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 10,
                                  color: Color(0xFF000000),
                                ),
                                children: [
                                  TextSpan(
                                    text: '33°C 
                          ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Sunny',
                                  ),
                                  TextSpan(
                                    text: '  ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 33, 0, 0),
                      child: Text(
                        '11 Aug, 12:00 Pm',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 10,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 0, 25, 5),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFF2F2F2),
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(4, 9, 4.6, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage(
                                    'assets/images/windy_weather.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 40,
                                height: 40,
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 2, 0, 2),
                            child: RichText(
                              text: TextSpan(
                                text: 'Friday 10 August
                          45',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 10,
                                  color: Color(0xFF000000),
                                ),
                                children: [
                                  TextSpan(
                                    text: '°C 
                          ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Strong Gale',
                                  ),
                                  TextSpan(
                                    text: '  ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 33, 0, 0),
                      child: Text(
                        '10 Aug, 11:00 Pm',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 10,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 0, 25, 5),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFF2F2F2),
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(4, 9, 7.7, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 20, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage(
                                    'assets/images/night.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 40,
                                height: 40,
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 2, 0, 2),
                            child: RichText(
                              text: TextSpan(
                                text: 'Friday 10 August
                          30',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 10,
                                  color: Color(0xFF000000),
                                ),
                                children: [
                                  TextSpan(
                                    text: '°C 
                          ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Cloudy',
                                  ),
                                  TextSpan(
                                    text: '  ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 33, 0, 0),
                      child: Text(
                        '10 Aug, 9:45 Pm',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 10,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 0, 25, 5),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFF2F2F2),
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(4, 9, 9.3, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 18, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage(
                                    'assets/images/storm.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 40,
                                height: 40,
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 2, 0, 2),
                            child: RichText(
                              text: TextSpan(
                                text: 'Friday 10 August
                          28',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 10,
                                  color: Color(0xFF000000),
                                ),
                                children: [
                                  TextSpan(
                                    text: '°C 
                          ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Lightning',
                                  ),
                                  TextSpan(
                                    text: '  ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 33, 0, 0),
                      child: Text(
                        '11 Aug, 9:00 Pm',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 10,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 0, 25, 5),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFFD9433),
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(4, 9, 4.8, 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 5),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 0, 18, 0),
                            child: Container(
                              decoration: BoxDecoration(
                                image: DecorationImage(
                                  fit: BoxFit.contain,
                                  image: AssetImage(
                                    'assets/images/heavy_rain.png',
                                  ),
                                ),
                              ),
                              child: Container(
                                width: 40,
                                height: 40,
                              ),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(0, 2, 0, 2),
                            child: RichText(
                              text: TextSpan(
                                text: 'Friday 10 August
                          50',
                                style: GoogleFonts.getFont(
                                  'Inter',
                                  fontWeight: FontWeight.w400,
                                  fontSize: 10,
                                  color: Color(0xFF000000),
                                ),
                                children: [
                                  TextSpan(
                                    text: '°C 
                          ',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      height: 1.3,
                                    ),
                                  ),
                                  TextSpan(
                                    text: 'Heavy rain',
                                    style: GoogleFonts.getFont(
                                      'Inter',
                                      fontWeight: FontWeight.w400,
                                      fontSize: 10,
                                      color: Color(0xFF000000),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 33, 0, 0),
                      child: Text(
                        '11 Aug, 12:00 Pm',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w400,
                          fontSize: 10,
                          color: Color(0xFF000000),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 0, 25, 5),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFF2F2F2),
              ),
              child: Container(
                width: 315,
                height: 60,
              ),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(20, 0, 25, 10),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(15),
                color: Color(0xFFF2F2F2),
              ),
              child: Container(
                width: 315,
                height: 60,
              ),
            ),
            Container(
              padding: EdgeInsets.fromLTRB(27, 6, 24.1, 3),
              decoration: BoxDecoration(
                border: Border.all(color: Color(0xFF000000)),
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(5),
                  topRight: Radius.circular(5),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 37, 1),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(5, 28, 6.4, 0),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Text(
                              'Alert',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w500,
                                fontSize: 8,
                                color: Color(0xFF000000),
                              ),
                            ),
                            Positioned(
                              top: -28,
                              child: SizedBox(
                                width: 30,
                                height: 30,
                                child: SvgPicture.asset(
                                  'assets/vectors/alert_triangle_3_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 38, 0),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(0, 29, 0, 0),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Text(
                              'Location',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w500,
                                fontSize: 8,
                                color: Color(0xFF000000),
                              ),
                            ),
                            Positioned(
                              right: 1,
                              top: 0,
                              child: SizedBox(
                                width: 30,
                                height: 30,
                                child: SvgPicture.asset(
                                  'assets/vectors/map_pin_3_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 37, 0),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(4, 29, 3.5, 0),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Text(
                              'Home',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w500,
                                fontSize: 8,
                                color: Color(0xFF000000),
                              ),
                            ),
                            Positioned(
                              top: -29,
                              child: SizedBox(
                                width: 30,
                                height: 30,
                                child: SvgPicture.asset(
                                  'assets/vectors/home_1_x2.svg',
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 37.7, 0),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(0, 29, 0, 0),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Text(
                              'Weather',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w500,
                                fontSize: 8,
                                color: Color(0xFF000000),
                              ),
                            ),
                            Positioned(
                              left: 2,
                              right: 0.3,
                              top: 0,
                              child: Container(
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    fit: BoxFit.contain,
                                    image: AssetImage(
                                      'assets/images/warm_weather.png',
                                    ),
                                  ),
                                ),
                                child: Container(
                                  width: 30,
                                  height: 30,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 1, 0, 0),
                      child: Container(
                        padding: EdgeInsets.fromLTRB(0, 28, 0, 0),
                        child: Stack(
                          clipBehavior: Clip.none,
                          children: [
                            Text(
                              'Account',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w500,
                                fontSize: 8,
                                color: Color(0xFF000000),
                              ),
                            ),
                            Positioned(
                              left: 1,
                              right: 0.9,
                              top: 0,
                              child: Container(
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    fit: BoxFit.contain,
                                    image: AssetImage(
                                      'assets/images/male_user.png',
                                    ),
                                  ),
                                ),
                                child: Container(
                                  width: 30,
                                  height: 30,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}