import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class Login1Pg extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFF0386FF),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(0, 163, 0, 0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(color: Color(0xFFDCDCDC)),
            color: Color(0xFFF6F6F6),
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(75),
            ),
          ),
          child: SizedBox(
            width: double.infinity,
            child: Container(
              padding: EdgeInsets.fromLTRB(21, 23, 21, 34),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 1, 0),
                    child: Text(
                      'Quick Shield',
                      style: GoogleFonts.getFont(
                        'Italiana',
                        fontWeight: FontWeight.w400,
                        fontSize: 40,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0.4, 43),
                    child: Text(
                      'Disaster Preparedness Services',
                      style: GoogleFonts.getFont(
                        'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: 15,
                        color: Color(0xFF000000),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 27),
                    child: Align(
                      alignment: Alignment.topRight,
                      child: Container(
                        width: 297,
                        decoration: BoxDecoration(
                          border: Border.all(color: Color(0xFF616161)),
                          boxShadow: [
                            BoxShadow(
                              color: Color(0x40000000),
                              offset: Offset(3, 4),
                              blurRadius: 2.5,
                            ),
                          ],
                        ),
                        child: Container(
                          padding: EdgeInsets.fromLTRB(12.6, 0, 0, 0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 10.5, 10.5, 11.6),
                                width: 30,
                                height: 30,
                                child: SizedBox(
                                  width: 24.9,
                                  height: 24.9,
                                  child: SvgPicture.asset(
                                    'assets/vectors/vector_8_x2.svg',
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 0, 6, 0),
                                child: Container(
                                  decoration: BoxDecoration(
                                    color: Color(0xFF808080),
                                  ),
                                  child: Container(
                                    width: 51,
                                    height: 0,
                                  ),
                                ),
                              ),
                              Container(
                                margin: EdgeInsets.fromLTRB(0, 14, 0, 11),
                                child: Text(
                                  'Enter Phone Number',
                                  style: GoogleFonts.getFont(
                                    'Inter',
                                    fontWeight: FontWeight.w500,
                                    fontSize: 18,
                                    color: Color(0xFF9D9D9D),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 27),
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xFF808080)),
                      borderRadius: BorderRadius.circular(35),
                      color: Color(0xFF2A6CB8),
                    ),
                    child: Container(
                      width: 120,
                      padding: EdgeInsets.fromLTRB(0, 13, 0.5, 12),
                      child: Text(
                        'Login',
                        style: GoogleFonts.getFont(
                          'Inter',
                          fontWeight: FontWeight.w500,
                          fontSize: 15,
                          color: Color(0xFFFFFFFF),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 26),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          margin: EdgeInsets.fromLTRB(0, 0, 0.2, 0),
                          child: Text(
                            'Dont have Phone Number?',
                            style: GoogleFonts.getFont(
                              'Inter',
                              fontWeight: FontWeight.w500,
                              fontSize: 13,
                              color: Color(0xFFBFBFBF),
                            ),
                          ),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Color(0xFFCCCCCC),
                          ),
                          child: Container(
                            width: 166,
                            height: 0,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(1, 0, 0, 70),
                    decoration: BoxDecoration(
                      border: Border.all(color: Color(0xFF919191)),
                      borderRadius: BorderRadius.circular(40),
                      color: Color(0xFF5479DA),
                    ),
                    child: SizedBox(
                      width: 155,
                      child: Container(
                        padding: EdgeInsets.fromLTRB(0, 3, 0, 2),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              margin: EdgeInsets.fromLTRB(0, 0, 6, 0),
                              child: Container(
                                decoration: BoxDecoration(
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    image: AssetImage(
                                      'assets/images/language_1.png',
                                    ),
                                  ),
                                ),
                                child: Container(
                                  width: 18,
                                  height: 18,
                                ),
                              ),
                            ),
                            Text(
                              'Language',
                              style: GoogleFonts.getFont(
                                'Inter',
                                fontWeight: FontWeight.w500,
                                fontSize: 15,
                                color: Color(0xFF000000),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(0.5, 0, 0, 0),
                    child: Text(
                      'Developed and Maintained by Titans',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w500,
                        fontSize: 13,
                        color: Color(0xFF5B5B5B),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}