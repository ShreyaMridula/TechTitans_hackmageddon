import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class MapPin extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Stack(
      children: [
          Positioned(
            left: -6,
            right: -6,
            top: -6,
            bottom: -10,
            child: SizedBox(
              width: 18,
              height: 22,
              child: SvgPicture.asset(
                'assets/vectors/vector_1_x2.svg',
              ),
            ),
          ),
    Container(
          padding: EdgeInsets.fromLTRB(6, 6, 6, 10),
          child: SizedBox(
            width: 6,
            height: 6,
            child: SvgPicture.asset(
              'assets/vectors/vector_3_x2.svg',
            ),
          ),
        ),
      ],
    );
  }
}