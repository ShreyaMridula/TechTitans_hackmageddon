import 'package:flutter/material.dart';

import 'package:flutter_app/pages/account_pg.dart';
import 'package:flutter_app/pages/alert_pg.dart';
import 'package:flutter_app/pages/confirmation_pg.dart';
import 'package:flutter_app/pages/cyclones.dart';
import 'package:flutter_app/pages/dos_and_donts.dart';
import 'package:flutter_app/pages/droughts.dart';
import 'package:flutter_app/pages/earthquake.dart';
import 'package:flutter_app/pages/email_pg.dart';
import 'package:flutter_app/pages/floods.dart';
import 'package:flutter_app/pages/hailstorms.dart';
import 'package:flutter_app/pages/home_pg.dart';
import 'package:flutter_app/pages/landslides.dart';
import 'package:flutter_app/pages/language_pg.dart';
import 'package:flutter_app/pages/location_pg.dart';
import 'package:flutter_app/pages/login_1_pg.dart';
import 'package:flutter_app/pages/login_pg.dart';
import 'package:flutter_app/pages/map_pin.dart';
import 'package:flutter_app/pages/tsunami.dart';
import 'package:flutter_app/pages/weather_pg.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      home: Scaffold(

        body: AccountPg(),
        // body: AlertPg(),
        // body: ConfirmationPg(),
        // body: Cyclones(),
        // body: DosAndDonts(),
        // body: Droughts(),
        // body: Earthquake(),
        // body: EmailPg(),
        // body: Floods(),
        // body: Hailstorms(),
        // body: HomePg(),
        // body: Landslides(),
        // body: LanguagePg(),
        // body: LocationPg(),
        // body: Login1Pg(),
        // body: LoginPg(),
        // body: MapPin(),
        // body: Tsunami(),
        // body: WeatherPg(),

      ),
    );
  }
}
