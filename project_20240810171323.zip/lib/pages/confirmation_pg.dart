import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:flutter_app/utils.dart';
import 'package:google_fonts/google_fonts.dart';

class ConfirmationPg extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return 
    Container(
      decoration: BoxDecoration(
        color: Color(0xFFF6F6F6),
      ),
      child: Container(
        padding: EdgeInsets.fromLTRB(16.3, 22.5, 35, 0),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            SizedBox(
              width: double.infinity,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    margin: EdgeInsets.fromLTRB(0, 0, 0, 77.5),
                    child: Align(
                      alignment: Alignment.topLeft,
                      child: Container(
                        width: 30,
                        height: 30,
                        child: SizedBox(
                          width: 7.5,
                          height: 15,
                          child: SvgPicture.asset(
                            'assets/vectors/vector_9_x2.svg',
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(18.8, 0, 0, 69),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFFB3B3B3),
                        borderRadius: BorderRadius.circular(60),
                      ),
                      child: Container(
                        width: 120,
                        height: 120,
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(18.8, 0, 0, 36),
                    child: ClipRect(
                      child: BackdropFilter(
                        filter: ImageFilter.blur(
                          sigmaX: 15.8999996185,
                          sigmaY: 15.8999996185,
                        ),
                        child: Container(
                          decoration: BoxDecoration(
                            border: Border.all(color: Color(0x032A4CB2)),
                            borderRadius: BorderRadius.circular(15),
                            color: Color(0x5C2A4CB2),
                          ),
                          child: Container(
                            padding: EdgeInsets.fromLTRB(13, 11, 0, 24),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Container(
                                  margin: EdgeInsets.fromLTRB(0, 0, 0, 36),
                                  child: Align(
                                    alignment: Alignment.topLeft,
                                    child: Text(
                                      'OTP',
                                      style: GoogleFonts.getFont(
                                        'Inter',
                                        fontWeight: FontWeight.w500,
                                        fontSize: 20,
                                        color: Color(0xFF252525),
                                      ),
                                    ),
                                  ),
                                ),
                                Container(
                                  margin: EdgeInsets.fromLTRB(18, 0, 0, 0),
                                  child: Align(
                                    alignment: Alignment.topCenter,
                                    child: SizedBox(
                                      width: 226,
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF252525),
                                            ),
                                            child: Container(
                                              width: 40,
                                              height: 0,
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF252525),
                                            ),
                                            child: Container(
                                              width: 40,
                                              height: 0,
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF252525),
                                            ),
                                            child: Container(
                                              width: 40,
                                              height: 0,
                                            ),
                                          ),
                                          Container(
                                            decoration: BoxDecoration(
                                              color: Color(0xFF252525),
                                            ),
                                            child: Container(
                                              width: 40,
                                              height: 0,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(17.8, 0, 0, 69),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFF2A6CB8),
                        borderRadius: BorderRadius.circular(40),
                      ),
                      child: Container(
                        width: 135,
                        padding: EdgeInsets.fromLTRB(0, 4, 0.8, 4),
                        child: Text(
                          'Submit',
                          style: GoogleFonts.getFont(
                            'Inter',
                            fontWeight: FontWeight.w500,
                            fontSize: 25,
                            color: Color(0xFF000000),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(16.7, 0, 0, 0),
                    child: Text(
                      'Resend Otp',
                      style: GoogleFonts.getFont(
                        'Inter',
                        fontWeight: FontWeight.w500,
                        fontSize: 15,
                        color: Color(0xFF3B3B3B),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.fromLTRB(16.8, 0, 0, 0),
                    child: Container(
                      decoration: BoxDecoration(
                        color: Color(0xFF3B3B3B),
                      ),
                      child: Container(
                        width: 84,
                        height: 0,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: 57.5,
              child: Container(
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.contain,
                    image: AssetImage(
                      'assets/images/person.png',
                    ),
                  ),
                ),
                child: Container(
                  width: 119,
                  height: 199,
                ),
              ),
            ),
            Positioned(
              top: 232.5,
              child: SizedBox(
                height: 24,
                child: Text(
                  '+91 xxxxxxxxxx',
                  style: GoogleFonts.getFont(
                    'Inter',
                    fontWeight: FontWeight.w500,
                    fontSize: 20,
                    color: Color(0xFF525252),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}